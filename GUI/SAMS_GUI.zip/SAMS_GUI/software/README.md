解压后运行：
   ./Student-Achieve-Management-System.sh

是.sh 不是没有sh 的那个
